<?php
/* Black Apple Inc.
 * http://black-apple.biz/
 * Dixie CMS
 * Created by Luthfie
 * luthfie@y7mail.com
 */

/* Include content header */
include_once('header.php');

/* View content body */
?>

<div>
  <h2><?php dixie_response_status(404); ?></h2>
</div>

<?php

/* Include content footer */
include_once('footer.php');
<?php
/* Dixie - Free and Simple CMS
 * Created by Luthfie a.k.a. 9r3i
 * luthfie@y7mail.com
 */

/* Include content header */
include_once('header.php');

/* View content body */
?>

<div>
  <h2><?php dixie_response_status(404); ?></h2>
</div>

<?php

/* Include content footer */
include_once('footer.php');
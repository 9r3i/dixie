        </div><!-- End of class body-right -->
        <div class="body-left">
          <aside>
            <div id="sidebar">
              <?php get_sidebar_print(); ?>
            </div>
          </aside>
        </div><!-- End of class body-left -->
        <div class="clear-both"></div>
      </div><!-- End of class body -->
    </div><!-- End of class tubuh -->
    <div id="loading"><div class="loader-image"></div></div>
    <div id="scroller" onclick="scroll_top('header')"></div>
    <footer>
      <div class="footer">
        <div class="footer-inside">
          <?php get_footer(); ?>
        </div>
      </div>
    </footer>
    <script src="<?php printf(WWW); ?>themes/Dixie2/js/dixie.js" type="text/javascript"></script>
  </body>
</html>